This folder contains processed example dataset used by the demos.
Copyright of the dataset belongs to the original copyright holder
